package miu.edu.race.application;

import miu.edu.race.framework.*;

public class JumpingCar extends Car {
    public void jump(){
        System.out.println("Jumping");
    }
}
