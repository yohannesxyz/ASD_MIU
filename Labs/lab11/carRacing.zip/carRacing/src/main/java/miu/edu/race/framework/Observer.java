package miu.edu.race.framework;

public interface Observer {
	public void update(int speed);
}
