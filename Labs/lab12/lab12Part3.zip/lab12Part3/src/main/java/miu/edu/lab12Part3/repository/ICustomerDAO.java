package miu.edu.lab12Part3.repository;

import miu.edu.lab12Part3.domain.Customer;

public interface ICustomerDAO {
    void save(Customer customer);
}
