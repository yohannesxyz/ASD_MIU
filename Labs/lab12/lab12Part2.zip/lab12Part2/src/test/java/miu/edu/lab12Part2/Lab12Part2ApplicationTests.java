package miu.edu.lab12Part2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab12Part2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
