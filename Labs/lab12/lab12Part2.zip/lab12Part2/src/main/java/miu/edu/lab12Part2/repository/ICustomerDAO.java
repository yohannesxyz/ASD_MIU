package miu.edu.lab12Part2.repository;

import miu.edu.lab12Part2.domain.Customer;

public interface ICustomerDAO {
    void save(Customer customer);
}
