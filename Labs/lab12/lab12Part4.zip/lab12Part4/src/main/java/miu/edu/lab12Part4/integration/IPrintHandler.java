package miu.edu.lab12Part4.integration;

public interface IPrintHandler {
    void print();
    boolean handlePrint(String city);
}
