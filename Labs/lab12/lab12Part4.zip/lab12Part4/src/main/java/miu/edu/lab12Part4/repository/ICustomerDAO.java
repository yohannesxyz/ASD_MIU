package miu.edu.lab12Part4.repository;

import miu.edu.lab12Part4.domain.Customer;

public interface ICustomerDAO {
    void save(Customer customer);
}
