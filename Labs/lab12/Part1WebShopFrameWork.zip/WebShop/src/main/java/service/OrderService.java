package service;

import dao.OrderDAO;
import domain.*;

import java.util.Optional;
import java.util.Random;

public class OrderService {
    private OrderDAO orderDAO;

    public OrderService() {
        this.orderDAO = new OrderDAO();
    }

    public Order createOrder(ShoppingCart shoppingCart, Customer customer, Address shippingAddress, Address billingAddress, PaymentStrategy payment) {
        long id = (new Random()).nextLong();
        Order order = new Order(id, shoppingCart, customer, shippingAddress, billingAddress, payment);
        order = orderDAO.add(order);
        return order;
    }

    public Order findOrder(long orderNumber) {
        Optional<Order> orderOptional = orderDAO.find(orderNumber);
        return orderOptional.orElse(null);
    }
}
