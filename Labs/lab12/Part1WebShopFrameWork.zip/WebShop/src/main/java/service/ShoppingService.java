package service;

import dao.ShoppingDAO;
import domain.*;
import emailsender.EmailSender;

import java.util.Optional;

public class ShoppingService {
    private ShoppingDAO shoppingCartDAO;
    private OrderService orderService;
    private EmailSender emailSender;

    public ShoppingService() {
        this.shoppingCartDAO = new ShoppingDAO();
        this.orderService = new OrderService();
        this.emailSender = new EmailSender();
    }

    public ShoppingCart findCart(long shoppingCartId) {
        Optional<ShoppingCart> shoppingCartOptional = shoppingCartDAO.find(shoppingCartId);
        return shoppingCartOptional.orElse(null);
    }
    public ShoppingCart addToCart(ShoppingCart shoppingCart, Product product, int quantity) {
        shoppingCart = shoppingCart.addItem(product, quantity);
        return shoppingCart;
    }

    public ShoppingCart removeFromCart(ShoppingCart shoppingCart, Product product) {
        shoppingCart = shoppingCart.removeItem(product);
        return shoppingCart;
    }

    public ShoppingCart updateQuantity(ShoppingCart shoppingCart, Product product, int quantity) {
        shoppingCart = shoppingCart.updateItemQuantity(product, quantity);
        return shoppingCart;
    }

    public Order checkout(ShoppingCart shoppingCart, Customer customer, Address shippingAddress, Address billingAddress, PaymentStrategy paymentStrategy) {
        double total = shoppingCart.getItems().stream()
                .mapToDouble(cartItem -> cartItem.getProduct().getPrice() * cartItem.getQuantity())
                .sum();
        paymentStrategy.setAmount(total);
        Order order = orderService.createOrder(shoppingCart, customer, shippingAddress, billingAddress, paymentStrategy);
        emailSender.sendEmail("Order Created!");
        return order;
    }
}
