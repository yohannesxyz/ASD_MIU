package service;

import dao.ProductDAO;
import domain.Product;

import java.util.Optional;
import java.util.Random;

public class ProductService {
    private ProductDAO productDAO;

    public ProductService() {
        this.productDAO = new ProductDAO();
    }

    public Product addNewProduct(String name, double price) {
        long id = (new Random()).nextLong();
        Product product = new Product(id, name, price);
        product = productDAO.add(product);
        return product;
    }

    public Product findProduct(long id) {
        Optional<Product> productOptional = productDAO.find(id);
        return productOptional.orElse(null);
    }
}
