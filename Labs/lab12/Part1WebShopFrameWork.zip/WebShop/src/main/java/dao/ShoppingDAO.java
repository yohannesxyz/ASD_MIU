package dao;

import domain.Item;
import domain.Product;
import domain.ShoppingCart;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class ShoppingDAO {
    Random random = new Random();
    private List<ShoppingCart> shoppingCarts = new ArrayList<>(List.of(
            new ShoppingCart(1L, new ArrayList<>(List.of(
                    new Item(new Product(random.nextLong(), "Product 1", 12.5), 2),
                    new Item(new Product(random.nextLong(), "Product 2", 23.5), 1)
            ))),
            new ShoppingCart(2L, new ArrayList<>(List.of(
                    new Item(new Product(random.nextLong(), "Product 2", 23.5), 1),
                    new Item(new Product(random.nextLong(), "Product 3", 34.8), 3)
            )))
    ));

    public ShoppingCart add(ShoppingCart shoppingCart) {
        shoppingCarts.add(shoppingCart);
        return shoppingCart;
    }

    public Optional<ShoppingCart> find(long shoppingCartId) {
        return shoppingCarts.stream()
                .filter(shoppingCart -> shoppingCart.getId() == shoppingCartId)
                .findFirst();
    }
}
