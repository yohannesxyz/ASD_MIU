package dao;

import domain.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class OrderDAO {
    private List<Order> orders = new ArrayList<>(List.of(
            new Order(1,
                    new ShoppingCart(2L, List.of(
                            new Item(new Product(1L,"prodcut 1",12.99), 1),
                            new Item(new Product(3L, "Product 3", 34.99), 3)
                    )),
                    new Customer(1L, "John Doe", "john.doe@example.com", "+1234567890",
                            new Address("Iowa", "Fairfield", "IA","52557")),
                    new Address("Iowa", "Fairfield", "IA","52557"),
                    new Address("Iowa", "Burlington", "IA","52558"),
                    new CreditCard(83.99, new Date(), new Date(2028, 8, 9), 12345L, "Visa")
            ),
            new Order(2,
                    new ShoppingCart(1L, List.of(
                            new Item(new Product(1L, "Product 1", 13.9), 2)
                    )),
                    new Customer(2L, "Jane Smith", "jane.smith@example.com", "+9876543210", new Address("Iowa", "DesMoines", "IA","88234")),
                    new Address("Iowa", "DesMoines", "IA","88234"),
                    new Address("Iowa", "Ottamwa", "IA","88235"),
                    new CreditCard(27.8, new Date(), new Date(2028, 8, 9), 98324, "MasterCard")
            )
    ));

    public Order add(Order order) {
        orders.add(order);
        return order;
    }

    public Optional<Order> find(long orderNumber) {
        return orders.stream()
                .filter(order -> order.getOrderNumber() == orderNumber)
                .findFirst();
    }
}
