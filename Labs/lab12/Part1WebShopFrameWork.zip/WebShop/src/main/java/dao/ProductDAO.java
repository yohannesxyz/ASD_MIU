package dao;

import domain.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class ProductDAO {
    Random random = new Random();

    private List<Product> products = new ArrayList<>(List.of(
            new Product(1L, "Product 1", 10.99),
            new Product(2L, "Product 2", 21.99),
            new Product(3L, "Product 3", 32.99),
            new Product(random.nextLong(), "Product 4", 43.99),
            new Product(random.nextLong(), "Product 5", 54.99)
    ));

    public Product add(Product product) {
        products.add(product);
        return product;
    }

    public Optional<Product> find(long id) {
        return products.stream()
                .filter(order -> order.getProductId() == id)
                .findFirst();
    }
}
