package domain;

public class Order {
    private long orderNumber;
    private ShoppingCart shoppingCart;
    private Customer customer;
    private Address shippingAddress;
    private Address billingAddress;
    private PaymentStrategy payment;

    public Order(long orderNumber, ShoppingCart shoppingCart, Customer customer,
                 Address shippingAddress, Address billingAddress, PaymentStrategy payment) {
        this.orderNumber = orderNumber;
        this.shoppingCart = shoppingCart;
        this.customer = customer;
        this.shippingAddress = shippingAddress;
        this.billingAddress = billingAddress;
        this.payment = payment;
    }

    public long getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(long orderNumber) {
        this.orderNumber = orderNumber;
    }

    public ShoppingCart getShoppingCart() {
        return shoppingCart;
    }

    public void setShoppingCart(ShoppingCart shoppingCart) {
        this.shoppingCart = shoppingCart;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public Address getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(Address billingAddress) {
        this.billingAddress = billingAddress;
    }

    public PaymentStrategy getPayment() {
        return payment;
    }

    public void setPayment(PaymentStrategy payment) {
        this.payment = payment;
    }
    @Override
    public String toString() {
        return "Order{" + "orderNumber=" + orderNumber + ", shoppingCart=" + shoppingCart + ", customer=" + customer + ", shippingAddress=" + shippingAddress + ", billingAddress=" + billingAddress + ", payment=" + payment + '}';
    }
}
