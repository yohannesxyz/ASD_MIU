package domain;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private Long id;
    private List<Item> items= new ArrayList<Item>();
    public ShoppingCart() {
    }
    public ShoppingCart(Long id, List<Item> items) {
        this.id = id;
        this.items = items;
    }
    public Long getId() {
        return id;
    }
    public List<Item> getItems() {
        return items;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public void setItems(List<Item> items) {
        this.items = items;
    }
    public ShoppingCart addItem(Product product, int quantity) {
        Item item = new Item(product, quantity);
        items.add(item);
        return this;
    }
    public ShoppingCart removeItem(Product product) {
        for (Item item : items) {
            if (item.getProduct().equals(product)) {
                items.remove(item);
                break;
            }
        }
        return this;
    }
    public ShoppingCart updateItemQuantity(Product product, int quantity) {
        for (Item item : items) {
            if (item.getProduct().equals(product)) {
                item.setQuantity(quantity);
                break;
            }
        }
        return this;
    }
    public double getTotalPrice() {
        double totalPrice = 0;
        for (Item item : items) {
            totalPrice += item.getTotalPrice();
        }
        return totalPrice;
    }
    @Override
    public String toString() {
        return "ShoppingCart{" + "id=" + id + ", items=" + items + '}';
    }
}
