package domain;

public class OrderLine {
}
