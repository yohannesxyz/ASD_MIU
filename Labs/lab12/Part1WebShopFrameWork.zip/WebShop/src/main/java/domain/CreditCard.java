package domain;

import java.util.Date;

public class CreditCard extends PaymentStrategy{
    private long creditCardNumber;
    private String creditCardType;
    public CreditCard() {
    }
    public CreditCard(Double amount, Date paymentDate, Date validationDate,
                      long creditCardNumber, String creditCardType) {
        super(amount, paymentDate, validationDate);
        this.creditCardNumber = creditCardNumber;
        this.creditCardType = creditCardType;
    }

    public long getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(long creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public String getCreditCardType() {
        return creditCardType;
    }

    public void setCreditCardType(String creditCardType) {
        this.creditCardType = creditCardType;
    }
}
