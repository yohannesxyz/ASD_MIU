package domain;

import java.util.Date;

public abstract class PaymentStrategy {
    protected double amount;
    protected Date paymentDate;
    protected Date validationDate;

    public PaymentStrategy() {
    }
    public PaymentStrategy(double amount, Date paymentDate, Date validationDate) {
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.validationDate = validationDate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Date getValidationDate() {
        return validationDate;
    }

    public void setValidationDate(Date validationDate) {
        this.validationDate = validationDate;
    }
}
