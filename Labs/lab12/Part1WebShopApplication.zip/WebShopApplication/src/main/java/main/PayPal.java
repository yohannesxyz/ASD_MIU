package main;

import domain.PaymentStrategy;

import java.util.Date;

public class PayPal extends PaymentStrategy {
    private Long payPalNumber;
    private String email;

    public PayPal(Double amount, Date paymentDate, Date validationDate,
                  Long payPalNumber, String email) {
        super(amount, paymentDate, validationDate);
        this.payPalNumber = payPalNumber;
        this.email = email;
    }
}
