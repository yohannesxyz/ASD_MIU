package main;

import domain.Address;

public class InternationalAddress {
    private Address address;
    private String country;
    public InternationalAddress() {
    }
    public InternationalAddress(Address address, String country) {
        this.address = address;
        this.country = country;
    }
    public Address getAddress() {
        return address;
    }
    public void setAddress(Address address) {
        this.address = address;
    }

    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
}
