package main;


import domain.*;
import service.ProductService;
import service.ShoppingService;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        ProductService productCatalog = new ProductService();
        Product product1 = productCatalog.addNewProduct("Banana", 7.90);
        Product product2 = productCatalog.findProduct(1L);
        Product product3 = productCatalog.findProduct(2L);
        Product product4 = productCatalog.findProduct(3L);
        productCatalog.addNewProduct("Orange", 3.90);

        ShoppingService shoppingService = new ShoppingService();
        ShoppingCart shoppingCart = shoppingService.findCart(1L);
        shoppingCart = shoppingService.addToCart(shoppingCart, product1, 30);
        shoppingCart = shoppingService.addToCart(shoppingCart, product2, 13);
        shoppingCart = shoppingService.addToCart(shoppingCart, product3, 1);
        shoppingCart = shoppingService.addToCart(shoppingCart, product4, 7);
        shoppingCart = shoppingService.removeFromCart(shoppingCart, product3);
        shoppingCart = shoppingService.updateQuantity(shoppingCart, product4, 11);

        System.out.println(shoppingCart);

        Address customerAddress = new Address("Iowa", "Fairfield", "IA","52557");
        Customer customer = new Customer(1L, "Rene", "renee@miu.edu", "+001254545", customerAddress);
        Address billingAddress = new Address("Iowa", "Fairfield", "IA", "52557");
        Address shippingAddress = new Address("Iowa", "Burlington","IA", "52558");
        PaymentStrategy paymentStrategy = new CreditCard(10.99, new Date(), new Date(2028, 8, 9), 98324, "MasterCard");

        Order order = shoppingService.checkout(shoppingCart, customer, billingAddress, shippingAddress, paymentStrategy);

        System.out.println(order);

    }

}