package miu.edu;

public interface Text {
    String getHTML();
}
