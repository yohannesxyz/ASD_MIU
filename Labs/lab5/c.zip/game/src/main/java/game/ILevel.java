package game;

public interface ILevel {
  int computePoints(Game game,int newPoints);
  String getLevel();
}
