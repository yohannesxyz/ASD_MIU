package paint;

public interface ICommand {
   public void execute();
   public void unExecute();
}
