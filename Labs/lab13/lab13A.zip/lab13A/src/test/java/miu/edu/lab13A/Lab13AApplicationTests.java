package miu.edu.lab13A;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab13AApplicationTests {

	@Test
	void contextLoads() {
	}

}
