package miu.edu.lab13A;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab13AApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab13AApplication.class, args);
	}

}
