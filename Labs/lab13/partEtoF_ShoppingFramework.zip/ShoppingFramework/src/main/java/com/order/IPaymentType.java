package com.order;

public interface IPaymentType {
}
