package customers.integration;

public interface IEmailSender {
    public void sendEmail(String to,String message);
}
