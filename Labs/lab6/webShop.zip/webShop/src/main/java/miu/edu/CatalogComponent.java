package miu.edu;

interface CatalogComponent {
    void print();
}