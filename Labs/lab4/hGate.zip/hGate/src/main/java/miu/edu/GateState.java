package miu.edu;

public enum GateState {
    OPEN,
    CLOSED,
    OPENING,
    CLOSING
}
